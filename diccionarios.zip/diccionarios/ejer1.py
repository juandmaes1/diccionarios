huespedes={101:'Juan Valdes', 105:'Paquita la del Barrio', 202: 'Mariana Pajon'} #definio un diccionario



print (huespedes) #imprimio todo el diccionario
print (huespedes.items()) #imprimio cada seccion del diccionario una por una

print (huespedes.keys()) #imprimio las claves del diccionario
for key in huespedes:
    print (key) #el ciclo hace que se imprma una por una cada clave

print (huespedes.values()) #imprime los valores
for key in huespedes:
    print (huespedes[key]) #imprime los valores uno por uno
print() #espacio

for habitacion in huespedes:
    print (habitacion,':',huespedes[habitacion])
print()
for habitacion,huesped in huespedes.items():    #imprime la clave  y el valor correspondiente
    print (habitacion,':',huespedes[key])
for indice, key in enumerate(huespedes):  #enumera las secciones del diccionario
    print (indice+1,key,huespedes[key])
print()

print (huespedes[105])      #imprime el valor de la clave 105
print (huespedes.get(105))

print ('====================================')

huespedes[102]='Fanny Lu'
huespedes[107]='Don Omar'               #declara nuevos valores al diccionario
huespedes.setdefault('109','Luis Miguel')

for huesped in huespedes.items():
    print (habitacion,':',huesped)  #recorre todo el diccionario
print()

registroshoy={201:'Vicente Fernandez',301:'Pepe Guardiola'} #nuevo diccionario
huespedes.update(registroshoy) #los sube al diccionario original
for habitacion, huesped in huespedes.items():
    print (habitacion,':',huesped)  #recorre el diccionario
print()

print ('====================================')

huespedes[107]='Ricky Martin' #nombra una variable pero no la mete en ek diccionario
print (huespedes)

print ('====================================')


del huespedes[102] #borra la llave 102
huespedes.pop(202) # Elimina y retorna el valor
print(huespedes)

print ('====================================')

copia1=huespedes.copy()
print ('copia1: ',copia1)
copia2={}                       # Nombra 2 variables y las iguala al diccionario
copia2.update(huespedes)
print ("copia2: ",copia2)

print ('====================================')

lista=[2,5,7,1]
diccio=dict.fromkeys(lista,"xxx")  #NOMBRA UN DICCIONARIO E IMPRIME EN CADA LLAVE EL TEXTO
print(diccio)

print ('====================================')
inventario={"plata": (500,2500), 'cartera' : ["Cedula","Moneda","Boletas"],'mecato':'Detodito','dias':1}
print (inventario)  #declara e imprime un inventario
inventario["cartera"].sort() #ORDEN ALFABETICO
print(inventario)
inventario["cartera"].remove("Monedas") #quita monedas pero no existe esta en el diccionario
print(inventario)
print(inventario.get("plata")[0])