t = (23,'a',(2.5,3.7,'x'),["perrito","gatito"],'Pepe') #crea una lista
print (t)
print (len(t)) #imprime la lista y su longitud


print ('=====================================')
print (t[0])   #imprime la poscion 0
print (t[3])    #imprime la poscion 3
print (t[1:3])   #imprime de la poscicion 1 a 3
print (t[3][1])  #imprime el dato numero 1 de la poscion 3


print ('====================================')
print (t[3])
t[3].append('lorito') #añade un dato
print (t)

print ('====================================')
for elemento in t:
    print (elemento) #recorre la lista

print ('====================================')
for index in range(0,len(t)):  #recorre la lista
    print (t[index])

print ('====================================')
if 'a' in t:
    print ("El elemento 'a' esta en la tupla") #validar si "a" esta en la lista

print ('====================================')
lista=list(t) #iguala variables
lista[1]='A' #nuevo valor en 1
print (lista)

tupla=tuple(lista)
print (tupla)

print ('====================================')
l = [(1,1), (2,4), (3,9), (4,16), (5,25)] #nueva lista
for x, y in l:
    print (x, ':', y)       #recorre la lista poscicion por posicion