estudiantes = {1:('Juan' , "090019", 3.5, 4, 4.5), 2:('Juana', "024001", 3,3.2,2.5), 3: ('Neso', "029019", 4.5, 5, 3.8)}

print("a quien quieres eliminar, inserte el numero del estudiante")
x = input()
del estudiantes[2]
print(estudiantes)

print("agrega un estudante")

estudiantes[4]='Laura', "030032", 3,3.4,2.2

print(estudiantes)
print(estudiantes[1])
